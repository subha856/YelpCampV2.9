
var mongoose = require("mongoose");
//******Schema Set UP*****
var campgroundSchema = new mongoose.Schema({
	name: String,
	price: String,
	image: String,
	description: String,
	author: {
		id: {
			type: mongoose.Schema.Types.ObjectId,
			ref: "User"			
		},
		username: String
	},
	//Refrencing the Comment and providing an Id
	comment: [
		{
			type: mongoose.Schema.Types.ObjectId,
			ref: "Comment"
		}
	]
});
// var Campground = mongoose.model("Campground",campgroundSchema); not required, we are exporting the file in teh below line
//******Schema Set UP*****

module.exports = mongoose.model("Campground", campgroundSchema);
