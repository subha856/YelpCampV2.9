var Campground = require("../models/campground");
var Comment = require("../models/comment");
var middlewareObj = {};

middlewareObj.checkCampgroundOwnership = function(req, res, next){
	if(req.isAuthenticated()){
	   //Find the campground Id to comapre with the user id
			Campground.findById(req.params.id, function(err, foundCampground){
				if(err){
					res.redirect("back") ;// just send the site to the previous one
				} else {
					//compare with the user. equals is a mongoose function to compare as the author.is is an object vs user.id is a string
					if(foundCampground.author.id.equals(req.user._id)){
						next();
					} else {
						res.redirect("back");
					};
				};   
			});
	};

}; 

middlewareObj.checkCommentOwnership = function(req, res, next){
	if(req.isAuthenticated()){
	   //Find the campground Id to comapre with the user id
			Comment.findById(req.params.comment_id, function(err, foundComment){
				//this will handle when u change the campground id on edit path
				if(err || !foundCampground){
					res.redirect("back") ;// just send the site to the previous one
				} else {
					//compare with the user. equals is a mongoose function to compare as the author.is is an object vs user.id is a string
					if(foundComment.author.id.equals(req.user._id)){
						next();
					} else {
						res.redirect("back");
					};
				};
			});	   
	   };
};

		
middlewareObj.isLoggedIn =	function(req, res, next){
	if(req.isAuthenticated()){
		return next();
	}
	req.flash("error", "Please Login First");
	res.redirect("/login");
};

module.exports =  middlewareObj;