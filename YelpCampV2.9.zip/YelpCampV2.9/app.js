var express = require("express"),
	app = express(),
	bodyParser = require("body-parser"),
	mongoose = require("mongoose"),
	passport = require("passport"),
	methodOverride = require("method-override"),
	LocalStrategy = require('passport-local').Strategy,
	flash = require("connect-flash"),
	Campground = require("./models/campground"), // models File require
	Comment = require("./models/comment"), // need this additionl step to access the comment
	User = require("./models/user"),
	seedDb = require("./seeds") // Calling seedDB - whatever is stored in it

//Requireing the route files
var commentRoutes = require("./routes/comments"),
	campgroundRoutes = require("./routes/campgrounds"),
	indexRoutes = require("./routes/index")


//******create yelpCamp database in mongodb*****
mongoose.connect('mongodb://localhost:27017/yelp_camp_feb05', {useNewUrlParser: true, useUnifiedTopology: true});
//******create yelpCamp database in mongodb*****
mongoose.set('useFindAndModify', false);

// seedDb(); // FUnction to seed the database

app.use(bodyParser.urlencoded({extended: true}));
app.set("view engine", "ejs");
app.use(express.static(__dirname + "/public")); // connecting style sheets
app.use(methodOverride("_method"));
app.use(flash());

//PASSPORT configuration
app.use(require("express-session")({
		secret: "My name id Don",
    	resave: false,
    	saveUninitialized: false
}));
app.use(passport.initialize());
app.use(passport.session());

passport.use(new LocalStrategy(User.authenticate())); //the user.authenticate method can only be used because we added the passportLocalMongoose plugin in user model 
passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());


app.listen(3000, function() { 
  console.log('Yelp Camp Server has started!!'); 
});

//This function or middleware will make sure the current user is avaliable to all routes
app.use(function(req, res, next){
	res.locals.currentUser = req.user;
	res.locals.error = req.flash("error"); // stored in error variable
	res.locals.success = req.flash("success"); // stored in success variable
	next();
});

// This tells our app to use those 3 files we have required
app.use(indexRoutes);
app.use("/campgrounds", campgroundRoutes);
app.use("/campgrounds/:id/comment", commentRoutes);

