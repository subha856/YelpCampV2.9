//Express router
var express = require("express");
var router = express.Router({mergeParams: true});
var Campground = require("../models/campground");
var middleware = require("../middleware"); //it will automatically require the content of index.js - it is like the home page

//Show Campgrounds
router.get("/", function(req, res){
	Campground.find({}, function(err, allcampgrounds){
		if(err){
			console.log(err);
			
		} else {
			res.render("campgrounds/campgrounds", {campgrounds: allcampgrounds, currentUser:req.user});
		}
	});
	
});


//CREATE New Campgrounds
router.post("/", middleware.isLoggedIn, function(req, res){
	
	var name = req.body.name;
	var image = req.body.image;
	var desc = req.body.description;
	var price = req.body.price;
	var author = {
		id:req.user._id,
		username: req.user.username
	};
	var newCampground = {name: name, image: image, description: desc, author: author, price: price};
	Campground.create(newCampground, function(err, newcampground){
		if(err){
			cosole.log(err);
		} else {
			res.redirect("/campgrounds");
		}
	});
	
});


//NEW - Campground form
router.get("/new", middleware.isLoggedIn,function(req, res){
	res.render("campgrounds/new")
});


//SHOW Campground by ID
router.get("/:id", function(req, res){
	Campground.findById(req.params.id).populate("comment").exec(function(err, foundCampground){
		if(err){
			console.log("Something went wrong");
			console.log(err);
		} else {
			res.render("campgrounds/show", {campground: foundCampground});

		}
	});

});

//EDIT & UPDATE Campgrounds
router.get("/:id/edit", middleware.checkCampgroundOwnership, function(req, res){
	Campground.findById(req.params.id, function(err, foundCampground){
			res.render("campgrounds/edit", {campground: foundCampground});
	});
});

//UPDATE:
router.put("/:id", middleware.checkCampgroundOwnership, function(req, res){
		   //Find & update the campground
	Campground.findByIdAndUpdate(req.params.id, req.body.campground, function(err, updatedCampground){
		if (err){
			res.redirect("/campgrounds")
		} else {
			res.redirect("/campgrounds/" + req.params.id)
		}
	});
});

//DESTROY/DELETE

router.delete("/:id", middleware.checkCampgroundOwnership, function(req, res){
		   //Find & update the campground
	Campground.findByIdAndDelete(req.params.id, function(err, deletedCampground){
		if (err){
			res.redirect("/campgrounds")
		} else {
			
			res.redirect("/campgrounds/")
			
		}
	});
});



//Middleware for Autherization:


//Middleware function


module.exports = router;
