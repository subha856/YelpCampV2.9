//Express router
var express = require("express");
var router = express.Router({mergeParams: true}); //this help us access the /:id from the routes
var Campground = require("../models/campground");
var Comment = require("../models/comment");
var middleware = require("../middleware"); //it will automatically require the content of index.js - it is like the home page

//ADD New Comment route
router.get("/new", middleware.isLoggedIn, function(req, res){
	Campground.findById(req.params.id ,function(err, campground){
		if(err){
			console.log("Something went wrong in GET");
			console.log(err);
		} else {
			console.log(campground);
			res.render("comment/new", {campground: campground});

		}
	});
});


//Comments Create
router.post("/", middleware.isLoggedIn, function(req, res){
	Campground.findById(req.params.id ,function(err, campground){
		if(err) {
			console.log("Something went wrong in POST");
			console.log(err);
			res.redirect("/campgrounds");
		} else {

				Comment.create(req.body.comment, function(err, comment){
					if(err){
						console.log(err);
					} else {
						// get the author info from the request and save- adding username and id to comment
						comment.author.id = req.user._id
						comment.author.username = req.user.username
						comment.save()
						
						campground.comment.push(comment);
						campground.save();
						res.redirect("/campgrounds/" + campground._id);
							}
				});
				}
	})
});


//Comments EDIT

router.get("/:comment_id/edit", middleware.checkCommentOwnership, function(req, res){
	    //Colt show this in a different way. As we dont have to do campground find by id because the req.params.id can be simply passed on for campground._id 
		//to the edit ejs like {campground_.id: req.params.id}
	
								// 	Campground.findById(req.params.id ,function(err, campground){
								// 	if(err){
								// 		console.log(err);
								// 	} else {
								// 		Comment.findById(req.params.comment_id ,function(err, comment){
								// 			if(err){
								// 				console.log(err);
								// 			} else{
								// 				res.render("comment/edit", {campground: campground, comment: comment});
								// 			}
								// 		});
								// 	}
								// });
	Comment.findById(req.params.comment_id, function(err, foundComment){
		if(err){
			res.redirect("back");
		} else{
			res.render("comment/edit", {campground_id: req.params.id, comment: foundComment});
		}
	});
});

//Comments UPDATE
router.put("/:comment_id", middleware.checkCommentOwnership, function(req, res){
		   //Find & update the campground. Also Important note. findOneAndUpdate did not work here, i had to use findByIdAndUpdate
	Comment.findByIdAndUpdate(req.params.comment_id, req.body.comment, function(err, updatedComment){

		if (err){
			res.redirect("/back")
		} else {
			console.log(req.params.comment_id);
			console.log(req.body.comment);
			res.redirect("/campgrounds/" + req.params.id)
		}
	});
});

//Comment DELETE/DESTROY </campgrounds/:id/comment/:comment_id

router.delete("/:comment_id", middleware.checkCommentOwnership, function(req, res){
	Comment.findByIdAndDelete(req.params.comment_id, function(err, deletedComment){
		if (err){
			res.redirect("/campgrounds")
		} else {
			res.redirect("/campgrounds/" + req.params.id)
		}
	});	
});

//Middleware for Autherization:


//Middleware function

module.exports = router;